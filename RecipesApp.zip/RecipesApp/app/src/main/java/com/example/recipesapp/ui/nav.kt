package com.example.recipesapp.ui

import RecipeListScreen
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument

@Composable
fun Navigation(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "login") {
        composable(route = "login") {
            LoginScreen(navController = navController)
        }
        composable(route = "recipes") {
            RecipeListScreen(navController = navController)
        }
        composable(route = "recipe/{id}", arguments = listOf(navArgument("id") { type = NavType.IntType })) {
            it.arguments?.let { it1 -> RecipeDetailsScreen(navController = navController, id = it1.getInt("id")) }
        }
    }
}