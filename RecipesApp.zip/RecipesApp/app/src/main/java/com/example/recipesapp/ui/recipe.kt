package com.example.recipesapp.ui

import Recipe
import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.example.recipesapp.R
import recipeList

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class, ExperimentalGlideComposeApi::class)
@Composable
fun RecipeDetailsScreen(id: Int, navController: NavHostController,) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Details") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp)
        ) {
            // Convert the recipe's image URL to a Painter using your preferred method

            GlideImage(
                model = recipeList[id].image,
                contentDescription = null,
                modifier = Modifier
                    .height(300.dp)
                    .fillMaxWidth(),
                contentScale = ContentScale.Crop,
            )

            Spacer(modifier = Modifier.padding(5.dp))

            Text(text = recipeList[id].name, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold,)

            Spacer(modifier = Modifier.padding(5.dp))

            Text(text = "Calories: ${recipeList[id].calories}", style = MaterialTheme.typography.bodyLarge)
            Text(text = "Carbos: ${recipeList[id].carbos}", style = MaterialTheme.typography.bodyLarge)
            Text(text = "Difficulty: ${recipeList[id].difficulty}", style = MaterialTheme.typography.bodyLarge)

            Spacer(modifier = Modifier.padding(5.dp))

            Text(text = "Description: ${recipeList[id].description}", style = MaterialTheme.typography.bodyMedium)
        }
    }
}